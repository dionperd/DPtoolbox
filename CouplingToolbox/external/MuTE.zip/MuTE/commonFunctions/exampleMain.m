%% Experiment using data from an epilectic patients http://math.bu.edu/people/kolaczyk/datasets.html
% 
% 
% Some explanations about how to set up the methods
% 
%     Method order: please take the order into account because afterwards
%     you should set a vector that needs the precise order of the methods
% 
%     binTransferEntropy                                 
%     nonUniformTransferEntropy                          
%     nonUniformTE_selectionVar             
%     predictiveInformation                              
%     linearTransferEntropy                              
%     linearNonUniformTransferEntropy                                                  
%     uniTENearNeighbour
%     nonUniTENearNeighbour
%     nonUniNN       
% 
% 
%     Parameters to specify for each method
% 
%%    binTransferEntropy Parameters
% 
%     idTargets             = [1 2];
%     idDrivers             = [2;1]';
%     modelOrder            = [5];
%     infoSeries            = [(1:numSeries)' , ones(numSeries,1).*paramsBinTransferEntropy.modelOrder, ones(numSeries,2),-ones(numSeries,1)];
%     multi_bivAnalysis     = 'multiv';
%     numQuantLevels        = 6;
%     orderCriterion        = 'bayesian';
%     entropyFun            = @conditionalEntropy;
%     preProcessingFun      = @quantization;
%     firstTermCaseVect     = firstCaseVect;%[1 0];
%     secondTermCaseVect    = secondCaseVect;%[1 1];
%     numSurrogates         = 100;
%     alphaPercentile       = 0.05;
%     tauMin                = 20;
%     ******** Set the following fields together *******
%     genCondTermFun        = @generateConditionalTerm;%@generateCondTermLagZero
%     usePresent            = 0;
% % **************************************************





    cd('/home/alessandro/Dropbox/Phd/toolbox_weHope/');
    addpath(genpath(pwd));

    nameMainDir  = 'expEpilepsy/';
    dataDir      = ['/home/alessandro/Documenti/Phd/' nameMainDir];
    
    numProcessors               = 4;


        
    %% EXPERIMENTS
    

    cd(dataDir);
%     defining the strings to distinguish the data files
    dataType1       = '_pre';
    dataType2       = '_ict';
%     making storing folders
    resDir1          = [dataDir 'expNonUniTransEnt' dataType1 '/'];
    if (~exist([dataDir 'resDir1'],'dir'))
        mkdir(resDir1);
    end
    copyDir1   = [resDir1 'entropyMatrices' dataType1 '/'];
    if (~exist([resDir1 'copyDir1'],'dir'))
        mkdir(copyDir1);
    end
    resDir2          = [dataDir 'expNonUniTransEnt' dataType2 '/'];
    if (~exist([dataDir 'resDir2'],'dir'))
        mkdir(resDir2);
    end
    copyDir2   = [resDir2 'entropyMatrices' dataType2 '/'];
    if (~exist([resDir2 'copyDir2'],'dir'))
        mkdir(copyDir2);
    end
    
    cd(dataDir);
    resultDir1           = [resDir1 'results_Seizure' dataType1 '/'];
    if (~exist([resDir1 'resultDir1'],'dir'))
        mkdir(resultDir1);
    end
    
    cd(dataDir);
    resultDir2           = [resDir2 'results_Seizure' dataType2 '/'];
    if (~exist([resDir2 'resultDir2'],'dir'))
        mkdir(resultDir2);
    end
%     defining the string to get data files
    dataFileName         = 'sz';
    
    channels             = 1:7;
    samplingRate         = 20;
    
    patients1            = dir([dataDir [dataFileName '*' dataType1 '*.dat']]);
    
    patients2            = dir([dataDir [dataFileName '*' dataType2 '*.dat']]);

       %% STATISTICAL METHODS

    fprintf('\n******************************\n\n');
    disp('Computing statistical methods...');
    fprintf('\n\n');
    
    tic
    [output1,params1]               = parametersAndMethods(patients1,samplingRate,channels,[0 1 1 0 0 0 0 0 0],dataType1,...
                                     resultDir1,dataDir,copyDir1,numProcessors,'nonUniformTE_selectionVar',[1 1],'nonUniformTransferEntropy',[1 1]);    
    [output2,params2]               = parametersAndMethods(patients2,sampling,channels,[0 1 0 0 0 0 0 0 0],dataType2,...
                                     resultDir2,dataDir,copyDir2,numProcessors,'nonUniformTE_selectionVar',[1 1]);
    toc
    
    fprintf('\n\n');
    disp('...computation statistical methods done!');
    fprintf('\n\n');
    
    cd('/home/alessandro/Dropbox/Phd/toolbox_weHope/');
    exit;


    
    
    