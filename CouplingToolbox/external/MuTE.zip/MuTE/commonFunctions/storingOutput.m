function [] = storingOutput(resultDir,realizations,params,output)

    cd(resultDir);
    
    methodNames      = fieldnames(params.methods);
    numMethods       = length(methodNames);
    for i = 1 : realizations
%         t = 1;
        for j = 1 : numMethods%length(methodInput)
%             if (ischar(methodInput{1,j}))
%                 methodNames{t}      = methodInput{1,j};
                if (strcmp('biv',params.methods.(methodNames{j}).multi_bivAnalysis))%(strcmp('biv',params.methods.(methodNames{t}).multi_bivAnalysis))
                    outputToStore     = output{1,i}{1,j};
                    caseName                  = [methodNames{j} '_BivAnalysis_patient_' num2str(i)];
                    save(caseName,'outputToStore');
                else
                    outputToStore     = output{1,i}{1,j};
                    caseName                  = [methodNames{j} '_MultivAnalysis_patient_' num2str(i)];
                    save(caseName,'outputToStore');
                end
%                 t = t+1;
%             end
        end
    end

return