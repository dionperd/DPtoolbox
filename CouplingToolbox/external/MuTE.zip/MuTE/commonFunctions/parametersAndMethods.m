function [output,params] = parametersAndMethods(patients,sampling,endPoint,channels,autoPairwiseTarDriv,handPairwiseTarDriv,resultDir,dataDir,copyDir,numProcessors,varargin)

    % Data: Time series in the rows
    realizations        = length(patients);
    numSeries           = length(channels);
    output              = cell(1,realizations);
    
    
    % ***************************************************************************************************
    %% Setting methods
    
    method_caseVect = find(strcmp('binTransferEntropy',varargin));
    binTransferEntropy = 0;
    if (~isempty(method_caseVect))
        binTransferEntropy                                 = 1;
        binUnifIdTargets                                   = varargin{1,method_caseVect+1};
        binUnifIdDrivers                                   = varargin{1,method_caseVect+2};
        binUnifIdOthersLagZero                             = varargin{1,method_caseVect+3};
        binUnifModelOrder                                  = varargin{1,method_caseVect+4};
        binUnifAnalysisType                                = varargin{1,method_caseVect+5};
        binUnifQuantumlevels                               = varargin{1,method_caseVect+6};
        binUnifOrderCriterion                              = varargin{1,method_caseVect+7};
        binUnifEntropyFun                                  = varargin{1,method_caseVect+8};
        binUnifPreProcessingFun                            = varargin{1,method_caseVect+9};
        binUnifCaseVect1                                   = varargin{1,method_caseVect+10};
        binUnifCaseVect2                                   = varargin{1,method_caseVect+11};
        binUnifNumSurrogates                               = varargin{1,method_caseVect+12};
        binUnifAlphaPercentile                             = varargin{1,method_caseVect+13};
        binUnifTauMin                                      = varargin{1,method_caseVect+14};
        binUnifGenerateCondTermFun                         = varargin{1,method_caseVect+15};
        binUnifUsePresent                                  = varargin{1,method_caseVect+16};
    end
    
    method_caseVect = find(strcmp('nonUniformTransferEntropy',varargin));
    nonUniformTransferEntropy = 0;
    if (~isempty(method_caseVect))
        nonUniformTransferEntropy                          = 1;
        binNonUnifIdTargets                                = varargin{1,method_caseVect+1};
        binNonUnifIdDrivers                                = varargin{1,method_caseVect+2};
        binNonUnifIdOthersLagZero                          = varargin{1,method_caseVect+3};
        binNonUnifModelOrder                               = varargin{1,method_caseVect+4};
        binNonUnifAnalysisType                             = varargin{1,method_caseVect+5};
        binNonUnifQuantumlevels                            = varargin{1,method_caseVect+6};
        binNonUnifEntropyFun                               = varargin{1,method_caseVect+7};
        binNonUnifPreProcessingFun                         = varargin{1,method_caseVect+8};
        binNonUnifCaseVect2                                = varargin{1,method_caseVect+9};
        binNonUnifNumSurrogates                            = varargin{1,method_caseVect+10};
        binNonUnifAlphaPercentile                          = varargin{1,method_caseVect+11};
        binNonUnifGenerateCondTermFun                      = varargin{1,method_caseVect+12};
        binNonUnifUsePresent                               = varargin{1,method_caseVect+13};
        binNonUnifScalpConduction                          = varargin{1,method_caseVect+14};
    end
    
    
    method_caseVect = find(strcmp('nonUniformTE_selectionVar',varargin));
    nonUniformTE_selectionVar = 0;
    if (~isempty(method_caseVect))
        nonUniformTE_selectionVar                          = 1;
        binNonUnifPC                                       = varargin{method_caseVect+1};
    end
    
    method_caseVect = find(strcmp('predictiveInformation',varargin));
    predictiveInformation = 0;
    if (~isempty(method_caseVect))
        predictiveInformation                              = 1;
        piIdTargets                                        = varargin{1,method_caseVect+1};
        piIdDrivers                                        = varargin{1,method_caseVect+2};
        piIdOthersLagZero                                  = varargin{1,method_caseVect+3};
        piModelOrder                                       = varargin{1,method_caseVect+4};
        piAnalysisType                                     = varargin{1,method_caseVect+5};
        piQuantumlevels                                    = varargin{1,method_caseVect+6};
        piEntropyFun                                       = varargin{1,method_caseVect+7};
        piPreProcessingFun                                 = varargin{1,method_caseVect+8};
        piCaseVect2                                        = varargin{1,method_caseVect+9};
        piNumSurrogates                                    = varargin{1,method_caseVect+10};
        piAlphaPercentile                                  = varargin{1,method_caseVect+11};
        piGenerateCondTermFun                              = varargin{1,method_caseVect+12};
        piUsePresent                                       = varargin{1,method_caseVect+13};
    end
    
    method_caseVect = find(strcmp('linearTransferEntropy',varargin));
    linearTransferEntropy = 0;
    if (~isempty(method_caseVect))
        linearTransferEntropy                              = 1;
        linUnifIdTargets                                   = varargin{1,method_caseVect+1};
        linUnifIdDrivers                                   = varargin{1,method_caseVect+2};
        linUnifIdOthersLagZero                             = varargin{1,method_caseVect+3};
        linUnifModelOrder                                  = varargin{1,method_caseVect+4};
        linUnifAnalysisType                                = varargin{1,method_caseVect+5};
        linUnifMinOrder                                    = varargin{1,method_caseVect+6};
        linUnifMaxOrder                                    = varargin{1,method_caseVect+7};
        linUnifOrderCriterion                              = varargin{1,method_caseVect+8};
        linUnifEntropyFun                                  = varargin{1,method_caseVect+9};
        linUnifCaseVect1                                   = varargin{1,method_caseVect+10};
        linUnifCaseVect2                                   = varargin{1,method_caseVect+11};
        linUnifGenerateCondTermFun                         = varargin{1,method_caseVect+12};
        linUnifUsePresent                                  = varargin{1,method_caseVect+13};
    end
    
    method_caseVect = find(strcmp('linearNonUniformTransferEntropy',varargin));
    linearNonUniformTransferEntropy = 0;
    if (~isempty(method_caseVect))
        linearNonUniformTransferEntropy                    = 1;
        linNonUnifIdTargets                                = varargin{1,method_caseVect+1};
        linNonUnifIdDrivers                                = varargin{1,method_caseVect+2};
        linNonUnifIdOthersLagZero                          = varargin{1,method_caseVect+3};
        linNonUnifModelOrder                               = varargin{1,method_caseVect+4};
        linNonUnifAnalysisType                             = varargin{1,method_caseVect+5};
        linNonUnifQuantumlevels                            = varargin{1,method_caseVect+6};
        linNonUnifEntropyFun                               = varargin{1,method_caseVect+7};
        linNonUnifCaseVect                                 = varargin{1,method_caseVect+8};
        linNonUnifNumSurrogates                            = varargin{1,method_caseVect+9};
        linNonUnifAlphaPercentile                          = varargin{1,method_caseVect+10};
        linNonUnifGenerateCondTermFun                      = varargin{1,method_caseVect+11};
        linNonUnifUsePresent                               = varargin{1,method_caseVect+12};
    end

    method_caseVect = find(strcmp('uniTENearNeighbour',varargin));
    uniTENearNeighbour = 0;
    if (~isempty(method_caseVect))
        uniTENearNeighbour                                 = 1;
        nearNeighUnifIdTargets                             = varargin{1,method_caseVect+1};
        nearNeighUnifIdDrivers                             = varargin{1,method_caseVect+2};
        nearNeighUnifIdOthersLagZero                       = varargin{1,method_caseVect+3};
        nearNeighUnifModelOrder                            = varargin{1,method_caseVect+4};
        nearNeighUnifAnalysisType                          = varargin{1,method_caseVect+5};
        nearNeighUnifCaseVect                              = varargin{1,method_caseVect+6};
        nearNeighUnifNumSurrogates                         = varargin{1,method_caseVect+7};
        nearNeighUnifMetric                                = varargin{1,method_caseVect+8};
        nearNeighUnifNumNearNei                            = varargin{1,method_caseVect+9};
        nearNeighUnifFuncDir                               = varargin{1,method_caseVect+10};
        nearNeighUnifHomeDir                               = varargin{1,method_caseVect+11};
        nearNeighUnifAlphaPercentile                       = varargin{1,method_caseVect+12};
        nearNeighUnifTauMin                                = varargin{1,method_caseVect+13};
        nearNeighUnifGenerateCondTermFun                   = varargin{1,method_caseVect+14};
        nearNeighUnifUsePresent                            = varargin{1,method_caseVect+15};
    end
    
    method_caseVect = find(strcmp('nonUniTENearNeighbour',varargin));
    nonUniTENearNeighbour = 0;
    if (~isempty(method_caseVect))
        nonUniTENearNeighbour                              = 1;
        nearNeighNonUnifIdTargets                          = varargin{1,method_caseVect+1};
        nearNeighNonUnifIdDrivers                          = varargin{1,method_caseVect+2};
        nearNeighNonUnifIdOthersLagZero                    = varargin{1,method_caseVect+3};
        nearNeighNonUnifModelOrder                         = varargin{1,method_caseVect+4};
        nearNeighNonUnifAnalysisType                       = varargin{1,method_caseVect+5};
        nearNeighNonUnifCaseVect                           = varargin{1,method_caseVect+6};
        nearNeighNonUnifNumSurrogates                      = varargin{1,method_caseVect+7};
        nearNeighNonUnifMetric                             = varargin{1,method_caseVect+8};
        nearNeighNonUnifNumNearNei                         = varargin{1,method_caseVect+9};
        nearNeighNonUnifInfoTransCriterionFun              = varargin{1,method_caseVect+10};
        nearNeighNonUnifSurroTestFun                       = varargin{1,method_caseVect+11};
        nearNeighNonUnifFuncDir                            = varargin{1,method_caseVect+12};
        nearNeighNonUnifHomeDir                            = varargin{1,method_caseVect+13};
        nearNeighNonUnifAlphaPercentile                    = varargin{1,method_caseVect+14};
        nearNeighNonUnifGenerateCondTermFun                = varargin{1,method_caseVect+15};
        nearNeighNonUnifUsePresent                         = varargin{1,method_caseVect+16};
    end
    
    method_caseVect = find(strcmp('nonUniNeuralNet',varargin));
    nonUniNeuralNet = 0;
    if (~isempty(method_caseVect))
        nonUniNeuralNet                                    = 1;
        nnData                                             = varargin{method_caseVect+1};
        nnIdTargets                                        = varargin{method_caseVect+2};
        nnIdDrivers                                        = varargin{method_caseVect+3};
        nnIdOtherLagZero                                   = varargin{method_caseVect+4};
        nnModelOrder                                       = varargin{method_caseVect+5};
        nnFirstTermCaseVect                                = varargin{method_caseVect+6};
        nnSecondTermCaseVect                               = varargin{method_caseVect+7};
        nnAnalysisType                                     = varargin{method_caseVect+8};
        nnEta                                              = varargin{method_caseVect+9};
        nnAlpha                                            = varargin{method_caseVect+10};
        nnNumHiddenNodes                                   = varargin{method_caseVect+11};
        nnFixHidden                                        = varargin{method_caseVect+12};
        nnMinHiddenNodes                                   = varargin{method_caseVect+13};
        nnMaxHiddenNodes                                   = varargin{method_caseVect+14};
        nnFidHiddenNodes                                   = varargin{method_caseVect+15};
        nnFracTrainSet                                     = varargin{method_caseVect+16};
        nnActFunc                                          = varargin{method_caseVect+17};
        nnNumEpochs                                        = varargin{method_caseVect+18};
        nnBias                                             = varargin{method_caseVect+19};
        nnInitType                                         = varargin{method_caseVect+20};
        nnEpochs                                           = varargin{method_caseVect+21};
        nnThreshold                                        = varargin{method_caseVect+22};
        nnSingleCandThreshold                              = varargin{method_caseVect+23};
        nnDividingPoint                                    = varargin{method_caseVect+24};
        nnValStep                                          = varargin{method_caseVect+25};
        nnValThreshold                                     = varargin{method_caseVect+26};
        nnStopEpochPerc                                    = varargin{method_caseVect+27};
        nnLearnAlg                                         = varargin{method_caseVect+28};
        nnRbpIncrease                                      = varargin{method_caseVect+29};
        nnRbpDescrease                                     = varargin{method_caseVect+30};
        nnCoeffNoise                                       = varargin{method_caseVect+31};
        nnRangeW                                           = varargin{method_caseVect+32};
        nnCoeffHidNodes                                    = varargin{method_caseVect+33};
        nnGenCondTermFun                                   = varargin{method_caseVect+34};
        nnUsePresent                                       = varargin{method_caseVect+35};
    else
        nnData                                             = [];
    end

    % ***************************************************************************************************
    %% Setting the parameters for each method:
    
    if (binTransferEntropy)
        paramsBinTransferEntropy  = createBinTransferEntropyParams(numSeries,binUnifIdTargets,binUnifIdDrivers,binUnifIdOthersLagZero,binUnifModelOrder,binUnifAnalysisType,...
                                    binUnifQuantumlevels,binUnifOrderCriterion,binUnifEntropyFun,binUnifPreProcessingFun,binUnifCaseVect1,...
                                    binUnifCaseVect2,binUnifNumSurrogates,binUnifAlphaPercentile,binUnifTauMin,binUnifGenerateCondTermFun,binUnifUsePresent);
        if (autoPairwiseTarDriv(1) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsBinTransferEntropy.idTargets = tarDrivRows(1,:);
            paramsBinTransferEntropy.idDrivers = tarDrivRows(2,:);
        end
    end

    if (nonUniformTransferEntropy)
        paramsNonUniformTransferEntropy = createNonUniformTransferEntropyParams(numSeries,binNonUnifIdTargets,binNonUnifIdDrivers,binNonUnifIdOthersLagZero,binNonUnifModelOrder,binNonUnifAnalysisType,...
                                          binNonUnifQuantumlevels,binNonUnifEntropyFun,binNonUnifPreProcessingFun,binNonUnifCaseVect2,...
                                          binNonUnifNumSurrogates,binNonUnifAlphaPercentile,binNonUnifGenerateCondTermFun,binNonUnifUsePresent,binNonUnifScalpConduction);
        if (autoPairwiseTarDriv(2) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsNonUniformTransferEntropy.idTargets = tarDrivRows(1,:);
            paramsNonUniformTransferEntropy.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (nonUniformTE_selectionVar)
        paramsNonUniformTE_selectionVar                  = createNonUniformTransferEntropySelecVarParams(numSeries,binNonUnifPC);
        if (autoPairwiseTarDriv(3) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsNonUniformTE_selectionVar.idTargets = tarDrivRows(1,:);
            paramsNonUniformTE_selectionVar.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (predictiveInformation)
        paramsPredictiveInformation = createPredictiveInformationParams(numSeries,piIdTargets,piIdDrivers,piIdOthersLagZero,piModelOrder,piAnalysisType,piQuantumlevels,piEntropyFun,...
                                      piPreProcessingFun,piCaseVect2,piNumSurrogates,piAlphaPercentile,piGenerateCondTermFun,piUsePresent);
        if (autoPairwiseTarDriv(4) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsPredictiveInformation.idTargets = tarDrivRows(1,:);
            paramsPredictiveInformation.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (linearTransferEntropy)
        paramsLinearTransferEntropy = createLinearTransferEntropyParams(numSeries,linUnifIdTargets,linUnifIdDrivers,linUnifIdOthersLagZero,linUnifModelOrder,linUnifAnalysisType,...
                                      linUnifMinOrder,linUnifMaxOrder,linUnifOrderCriterion,linUnifEntropyFun,linUnifCaseVect1,linUnifCaseVect2,linUnifGenerateCondTermFun,linUnifUsePresent);
        if (autoPairwiseTarDriv(5) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsLinearTransferEntropy.idTargets = tarDrivRows(1,:);
            paramsLinearTransferEntropy.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (linearNonUniformTransferEntropy)
        paramsLinearNonUniformTransferEntropy = createLinearNonUniformTransferEntropyParams(numSeries,linNonUnifIdTargets,linNonUnifIdDrivers,linNonUnifIdOthersLagZero,linNonUnifModelOrder,...
                                                linNonUnifAnalysisType,linNonUnifQuantumlevels,linNonUnifEntropyFun,linNonUnifCaseVect,linNonUnifNumSurrogates,...
                                                linNonUnifAlphaPercentile,linNonUnifGenerateCondTermFun,linNonUnifUsePresent);
        if (autoPairwiseTarDriv(6) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsLinearNonUniformTransferEntropy.idTargets = tarDrivRows(1,:);
            paramsLinearNonUniformTransferEntropy.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (uniTENearNeighbour)
        paramsUniTENearNeighbour = createUniTENearNeighbourParams(numSeries,nearNeighUnifIdTargets,nearNeighUnifIdDrivers,nearNeighUnifIdOthersLagZero,nearNeighUnifModelOrder,...
                                                nearNeighUnifAnalysisType,nearNeighUnifCaseVect,nearNeighUnifNumSurrogates,nearNeighUnifMetric,nearNeighUnifNumNearNei,...
                                                nearNeighUnifFuncDir,nearNeighUnifHomeDir,nearNeighUnifAlphaPercentile,nearNeighUnifTauMin,...
                                                nearNeighUnifGenerateCondTermFun,nearNeighUnifUsePresent);
        if (autoPairwiseTarDriv(7) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsUniTENearNeighbour.idTargets = tarDrivRows(1,:);
            paramsUniTENearNeighbour.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (nonUniTENearNeighbour)
        paramsNonUniTENearNeighbour = createNonUniTENearNeighbourParams(numSeries,nearNeighNonUnifIdTargets,nearNeighNonUnifIdDrivers,nearNeighNonUnifIdOthersLagZero,nearNeighNonUnifModelOrder,...
                                      nearNeighNonUnifAnalysisType,nearNeighNonUnifCaseVect,nearNeighNonUnifNumSurrogates,nearNeighNonUnifMetric,nearNeighNonUnifNumNearNei,...
                                      nearNeighNonUnifInfoTransCriterionFun,nearNeighNonUnifSurroTestFun,nearNeighNonUnifFuncDir,nearNeighNonUnifHomeDir,nearNeighNonUnifAlphaPercentile,...
                                      nearNeighNonUnifGenerateCondTermFun,nearNeighNonUnifUsePresent);
        if (autoPairwiseTarDriv(8) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsNonUniTENearNeighbour.idTargets = tarDrivRows(1,:);
            paramsNonUniTENearNeighbour.idDrivers = tarDrivRows(2,:);
        end
    end
    
    if (nonUniNeuralNet)
        paramsNonUniNeuralNet = createNonUniNeuralNetParams(numSeries,nnIdTargets,nnIdDrivers,nnIdOtherLagZero,nnModelOrder,nnFirstTermCaseVect,nnSecondTermCaseVect,nnAnalysisType,nnEta,nnAlpha,nnNumHiddenNodes,nnFixHidden,nnMinHiddenNodes,...
                                nnMaxHiddenNodes,nnFidHiddenNodes,nnFracTrainSet,nnActFunc,nnNumEpochs,nnBias,nnInitType,nnEpochs,nnThreshold,nnSingleCandThreshold,nnDividingPoint,...
                                nnValStep,nnValThreshold,nnStopEpochPerc,nnLearnAlg,nnRbpIncrease,nnRbpDescrease,nnCoeffNoise,nnRangeW,nnCoeffHidNodes,nnGenCondTermFun,nnUsePresent);
        if (autoPairwiseTarDriv(9) == 1)
            [tarDrivRows] = allAgainstAll (channels);
            paramsNonUniNeuralNet.idTargets = tarDrivRows(1,:);
            paramsNonUniNeuralNet.idDrivers = tarDrivRows(2,:);
        end
    end
    
    % ***************************************************************************************************
    %% Putting all the parameters in one structure
    
    if (binTransferEntropy)
        params.methods.binTransferEntropy = paramsBinTransferEntropy;
    end

    if (nonUniformTransferEntropy)
        params.methods.nonUniformTransferEntropy = paramsNonUniformTransferEntropy;
    end
    
    if (nonUniformTE_selectionVar)
        params.methods.nonUniformTE_selectionVar = paramsNonUniformTE_selectionVar;
    end
    
    if (predictiveInformation)
        params.methods.predictiveInformation = paramsPredictiveInformation;
    end
    
    if (linearTransferEntropy)
        params.methods.linearTransferEntropy = paramsLinearTransferEntropy;
    end
    
    if (linearNonUniformTransferEntropy)
        params.methods.linearNonUniformTransferEntropy = paramsLinearNonUniformTransferEntropy;
    end
    
    if (nonUniTENearNeighbour)
        params.methods.nonUniTENearNeighbour = paramsNonUniTENearNeighbour;
    end
    
    if (uniTENearNeighbour)
        params.methods.uniTENearNeighbour = paramsUniTENearNeighbour;
    end
    
    if (nonUniNeuralNet)
        params.methods.nonUniNeuralNet = paramsNonUniNeuralNet;
    end
 
    % ***************************************************************************************************
    %% Calling methods
    
    if (numProcessors > 1)
    try
        disp('Destroing any existance matlab pool session');
        matlabpool close;        
    catch
        disp('No matlab pool session found');
    end
        matlabpool(numProcessors)
    end
    
    cd(dataDir);
    for i = 1 : realizations%parfor
        dataLoaded               = load([dataDir patients(i,1).name]);
        if (isempty(nnData))
            dataNN               = dataLoaded.data(channels,1:sampling:(end-endPoint));%dataNN               = dataLoaded.data(channels,1:sampling);
        else
            dataNN               = nnData;
        end
        output{1,i}              = callingMethods(dataLoaded.data(channels,1:sampling:(end-endPoint)),dataNN,params);%callingMethods(dataLoaded.data(channels,1:sampling:end),dataNN,params);
    end

    % *****************************************************************
    %% Storing output
    storingOutput(resultDir,realizations,params,output);

    cd(dataDir);
    generateExpReport(copyDir,resultDir,params);

    checkAutoPairwise = find(autoPairwiseTarDriv,1);
    checkHandPairwise = find(handPairwiseTarDriv,1);
    if (~isempty(checkAutoPairwise) || ~isempty(checkHandPairwise))
        reshapeResults(copyDir,resultDir,autoPairwiseTarDriv,handPairwiseTarDriv,params);
    end

    methodNames      = fieldnames(params.methods);
    numMethods       = length(methodNames);
    cd(copyDir);
    for a = 1:numMethods
        if (strcmp(methodNames{a},'nonUniformTransferEntropy') || strcmp(methodNames{a},'linearNonUniformTransferEntropy')...
                || strcmp(methodNames{a},'nonUniTENearNeighbour') || strcmp(methodNames{a},'nonUniNeuralNet')...
                || strcmp(methodNames{a},'nonUniformTE_selectionVar'))
            cd(resultDir);
            modelOrder       = params.methods.(methodNames{a}).infoSeries(1,2);
            numTargetsBinUnif       = length(params.methods.(methodNames{a}).idTargets);
            for j = 1: numSeries-1 : numTargetsBinUnif
                finCanMtx           = zeros(realizations*modelOrder*numSeries,2);
                for i = 1 : realizations
                    fillPoint = find(finCanMtx(:,1) == 0);
                    fillPoint = fillPoint(1,1);
                    currReal  = dir([methodNames{a} '*_' num2str(i) '.mat']);
                    currReal  = load(currReal.name);
                    finCanMtx(fillPoint:(fillPoint-1)+size(currReal.outputToStore.finalCandidatesMtx{1,j}{1,1},1),:) = currReal.outputToStore.finalCandidatesMtx{1,j}{1,1};
                end
                finCanMtx   = finCanMtx(finCanMtx(:,1)>0,:);
                finCanMtx1  = finCanMtx;
                countCandidates   = zeros(1,realizations*modelOrder*numSeries);
                countCandidates1  = zeros(1,realizations*modelOrder*numSeries);
                labels            = cell(1,realizations*modelOrder*numSeries);
                labels1           = cell(1,realizations*modelOrder*numSeries);
                idSeriesLag       = zeros(realizations*modelOrder*numSeries,2);
                l = 1;
                while (~isempty(finCanMtx))
                    count          = 0;
                    count1         = 0;
                    tmpCandidate   = finCanMtx(1,1);
                    tmpCandidate1  = finCanMtx1(1,:);
                    tmpLengthFinCanMtx  = size(finCanMtx,1);
                    for i = 1 : tmpLengthFinCanMtx
                        if (tmpCandidate == finCanMtx(i,1))
                            count = count+1;
                            finCanMtx(i,:) = zeros(1,2);
                        end
                        if (tmpCandidate1 == finCanMtx1(i,:))
                            count1 = count1+1;
                            finCanMtx1(i,:) = zeros(1,2);
                        end
                    end

                    finCanMtx(finCanMtx(:,1)==0,:)   = [];
                    finCanMtx1(finCanMtx1(:,1)==0,:) = [];
                    countCandidates(1,l)  = count;
                    countCandidates1(1,l) = count1;
                    labels{1,l}           = num2str(tmpCandidate);
                    labels1{1,l}          = num2str(tmpCandidate1);
                    idSeriesLag(l,:)      = tmpCandidate1;
                    l = l+1;
                end
                currDriv = getRiducedDriv(params.methods.(methodNames{a}).idDrivers(:,j));
                currTar  = params.methods.(methodNames{a}).idTargets(1,j);
                countCandidates  = countCandidates(countCandidates>0);
                countCandidates1 = countCandidates1(countCandidates1>0);
                label          = labels(1,1:l-1);
                label1         = labels1(1,1:l-1);
                idSeriesLag    = [idSeriesLag(1:l-1,:) countCandidates1'];
                cd(copyDir);
                titleLabel     = [methodNames{a} 'labels' '_tar_' num2str(currTar)];
                titleIdSeriesLag = [methodNames{a} 'idSeriesLag' '_tar_' num2str(currTar)];
                save(titleLabel,'label');
                save(titleIdSeriesLag,'idSeriesLag');
                cd(resultDir);
                f1 = figure;
                set(f1,'Position',[1 1 1680 1050]);  
                bar(countCandidates);
                set( gca, 'XTickLabel', label,'FontSize',12);
                title(['Series picked up by ' methodNames{a} '  | driver ' num2str(currDriv') ' ; target ' num2str(currTar)],'FontSize',16);
                xlabel('Series Index','FontSize',20);
                ylabel('Counting','FontSize',20);
                f1SaveTitle = [methodNames{a} '_histAllCandidates_driv_' num2str(currDriv') '_tar_' num2str(currTar)];
                cd(copyDir);
                saveas(f1,f1SaveTitle);

                f2 = figure;
                set(f2,'Position',[1 1 1680 1050]);  
                bar(countCandidates1);
                set( gca, 'XTickLabel', label1,'FontSize',12);
                title(['Candidate picked up by ' methodNames{a} '  | driver ' num2str(currDriv') ' ; target ' num2str(currTar)],'FontSize',16);
                xlabel('Candidates','FontSize',20);
                ylabel('Counting','FontSize',20);
                f2SaveTitle = [methodNames{a} '_hist_driv_' num2str(currDriv') '_tar_' num2str(currTar)];
                cd(copyDir);
                saveas(f2,f2SaveTitle);
                cd(resultDir);
            end
            make3Dmatrix(copyDir,numSeries,modelOrder,methodNames{a});
        end
    end
    
    if (numProcessors > 1)
        matlabpool close;
    end
    
    
    
    
    
    
return;