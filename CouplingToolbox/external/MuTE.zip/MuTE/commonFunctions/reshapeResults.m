function reshapeResults(copyFolder,resultsFolder,autoPairwiseTarDriv,handPairwiseTarDriv,params)


    methodNames      = fieldnames(params.methods);
    numMethods       = length(methodNames);
    
    cd(resultsFolder);
        
%     channels = cell(1,numSeries);
%     
%     for i = 1:numSeries
%         channels{1,i} = i;
%     end
    
    for i = 1:numMethods
        if strcmp('binTransferEntropy',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,1) == 1 || handPairwiseTarDriv(1,1) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                teMtx = load([methodNames{i} '_transferEntropyMtx']);
                thresholdMtx = load([methodNames{i} '_testThresholdMtx']);
                significance = sum(teMtx.matrixTransferEntropy(:,2:end) > thresholdMtx.testThresholdMtx(:,2:end),1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('nonUniformTransferEntropy',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,2) == 1 || handPairwiseTarDriv(1,2) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                s = load([methodNames{i} '_significanceOnDriv']);
                significance = sum(s.significanceOnDrivers,1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('nonUniformTE_selectionVar',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,3) == 1 || handPairwiseTarDriv(1,3) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                meanImg = imagesc(meanRes);
                colormap(hot);
                colorbar;
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('predictiveInformation',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,4) == 1 || handPairwiseTarDriv(1,4) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                meanImg = imagesc(meanRes);
                colormap(hot);
                colorbar;
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('linearTransferEntropy',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,5) == 1  || handPairwiseTarDriv(1,5) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                teMtx = load([methodNames{i} '_transferEntropyMtx']);
                thresholdMtx = load([methodNames{i} '_matrixPValues']);
                significance = sum(teMtx.matrixTransferEntropy(:,2:end) > thresholdMtx.matrixPValues(:,2:end),1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('linearNonUniformTransferEntropy',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,6) == 1 || handPairwiseTarDriv(1,6) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                s = load([methodNames{i} '_significanceOnDriv']);
                significance = sum(s.significanceOnDrivers,1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('uniTENearNeighbour',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,7) == 1 || handPairwiseTarDriv(1,7) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                teMtx = load([methodNames{i} '_transferEntropyMtx']);
                thresholdMtx = load([methodNames{i} '_testThresholdMtx']);
                significance = sum(teMtx.matrixTransferEntropy(:,2:end) > thresholdMtx.testThresholdMtx(:,2:end),1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('nonUniTENearNeighbour',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,8) == 1 || handPairwiseTarDriv(1,8) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                s = load([methodNames{i} '_significanceOnDriv']);
                significance = sum(s.significanceOnDrivers,1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
        
        if strcmp('nonUniNeuralNet',methodNames{i})
            allResults = dir([methodNames{i} '*.mat']);
            if (autoPairwiseTarDriv(1,9) == 1 || handPairwiseTarDriv(1,9) == 1)
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    numTargets = size(outputToStore.params.infoSeries,1);
                    A = reshape(outputToStore.transferEntropy,numTargets-1,numTargets);
                    reshapedMtx = zeros(numTargets);
                    reshapedMtx(:,1) = [0;A(:,1)];
                    for j = 2:numTargets-1
                        reshapedMtx(:,j) = [A(1:j-1,j);0;A(j:end,j)];
                    end
                    reshapedMtx(:,numTargets) = [A(:,numTargets);0];
                    outputToStore.reshapedMtx = reshapedMtx;
                    save(allResults(t).name(1:end-4),'outputToStore');
                end
                meanResMtx = zeros(numTargets,numTargets);
                for t = 1:length(allResults)
                    load(allResults(t).name);
                    meanResMtx = meanResMtx + outputToStore.reshapedMtx;
                end
                meanRes = meanResMtx / length(allResults);
                save([methodNames{i} '_meanReshapeMtx'],'meanRes');
                cd(copyFolder);
                s = load([methodNames{i} '_significanceOnDriv']);
                significance = sum(s.significanceOnDrivers,1);
                B = reshape(significance,numTargets-1,numTargets);
                reshapedSigni = zeros(numTargets);
                reshapedSigni(:,1) = [0;B(:,1)];
                for j = 2:numTargets-1
                    reshapedSigni(:,j) = [B(1:j-1,j);0;B(j:end,j)];
                end
                reshapedSigni(:,numTargets) = [B(:,numTargets);0];
                save([methodNames{i} '_reshapedSignificance'],'reshapedSigni');
                cd(resultsFolder);
                meanImg = imagesc(meanRes);
                alpha(reshapedSigni / length(allResults));
                colormap(1-gray);
                colorbar;
                set(gca,'FontName','Times New Roman','FontSize',34);
                title(['row influences column  |  ' methodNames{i}],'FontSize',16);
                titleFig = [methodNames{i} '_meanReshapedMtx'];
                saveas(meanImg,titleFig,'png');
            end
        end
    end
    
%     numMeanReshapeMtx = dir('*meanReshapeMtx*mat');
%     min               = 0;
%     Max               = 0;
% %     getting the max of the figure scale
%     for i = 1:length(numMeanReshapeMtx)
%         tmpReshapeMtx = load(numMeanReshapeMtx(i).name);
%         tmp = max(Max,max(tmpReshapeMtx.meanRes(:)));
%         if (tmp > Max)
%             Max = tmp;
%         end
%     end
%     
%     for i = 1:length(numMeanReshapeMtx)
%         tmpReshapeMtx = load(numMeanReshapeMtx(i).name);
%         tmpNameFig    = ['meanImg' num2str(i)];
%         tmpNameFig    = figure;
%         imagesc(tmpReshapeMtx.meanRes, [min Max]);
%         colormap(hot);
%         colorbar;
%         title(['row influences column  |  ' numMeanReshapeMtx(i).name(1:end-19)],'FontSize',16);
%         titleFig = [numMeanReshapeMtx(i).name(1:end-19) '_meanReshapedMtx_sameScale'];
%         saveas(tmpNameFig,titleFig,'png');
%     end
    
return;





























