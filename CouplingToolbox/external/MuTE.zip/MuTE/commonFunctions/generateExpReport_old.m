function [transferEntropyMtx matrixPValues] = generateExpReport(outDir,params)

    methodNames          = fieldnames(params.methods);
    numMethods           = length(methodNames);
    transferEntropyMtx   = cell(1,numMethods);
    
    for i = 1 : numMethods
        cd(outDir)
        numTarget                          = length(params.methods.(methodNames{i,1}).idTargets);
        nameBaseFiles                      = [methodNames{i,1} '_firstCond_*'];
        nameTiltFiles                      = [methodNames{i,1} '_secondCond_*'];
        subjBaseFiles                      = dir(nameBaseFiles);
        subjTiltFiles                      = dir(nameTiltFiles);
        numSubj                            = length(subjBaseFiles);
        matrixTransferEntropy              = zeros(numSubj,(2*numTarget)+1);
%         check if is present the pValues matrix
        checkPValuesField                  = load(subjBaseFiles(1).name);
        fields                             = fieldnames(checkPValuesField);
        nameFields                         = checkPValuesField.(fields{1,1});
        if (isfield(nameFields,'pValue'))
            matrixPValues                  = zeros(numSubj,(2*numTarget)+1);
        end
        
        if (isfield(nameFields,'modelOrder'))
            modelOrder                     = zeros(numSubj,2);
        end
        
        for j = 1 : numSubj
            load(subjBaseFiles(j).name);
            load(subjTiltFiles(j).name);
            matrixTransferEntropy(j,2 : numTarget+1)                 = outputFirstCondToStore.transferEntropy;
            matrixTransferEntropy(j,numTarget+2 : 2*numTarget+1)     = outputSecondCondToStore.transferEntropy;
            matrixTransferEntropy(:,1)                               = (1:numSubj)';
            if (isfield(nameFields,'pValue'))
                matrixPValues(j,2 : numTarget+1)                     = outputFirstCondToStore.pValue;
                matrixPValues(j,numTarget +2 : 2*numTarget+1)        = outputSecondCondToStore.pValue;
                matrixPValues(:,1)                                   = (1:numSubj)';
                save('matrixPValues','matrixPValues');
            end
            
            if (isfield(nameFields,'bestOrder'))
                modelOrder(j,1)                                      = outputFirstCondToStore.bestOrder;
                modelOrder(j,2)                                      = outputSecondCondToStore.bestOrder;
            end
        end
        
        f     = fopen([outDir '/report_entropy_' methodNames{i,1} '.txt'],'w');
        
        
        if (isfield(nameFields,'bestOrder'))
            combinationsTarDriv     = repmat('%12s \t ',1,2*numTarget + 3);
            combinationsTarDriv     = [combinationsTarDriv '%12s\n'];
            fprintf(f,combinationsTarDriv,'Patient','modOrderB','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r','modOrderT','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r');
            fprintf(f,'\n--------------------------------------------------------\n\n');
            
            for j = 1 : numSubj
                fprintf(f,'\n       %2d           \t', matrixTransferEntropy(j,1));
                fprintf(f,'%2d           \t', modelOrder(j,1));
                for z = 2:numTarget+1
                    fprintf(f,'%.5f        \t',matrixTransferEntropy(j,z));
                end
                fprintf(f,'%2d           \t', modelOrder(j,2));
                for z = numTarget+2:2*numTarget+1
                    fprintf(f,'%.5f        \t',matrixTransferEntropy(j,z));
                end
            end
            
        else
            combinationsTarDriv     = repmat('%12s \t ',1,2*numTarget + 1);
            combinationsTarDriv     = [combinationsTarDriv '%12s\n'];
            fprintf(f,combinationsTarDriv,'Patient','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r');
            fprintf(f,'\n--------------------------------------------------------\n\n');
            
            for j = 1 : numSubj
                fprintf(f,'\n       %2d           \t', matrixTransferEntropy(j,1));
                for z = 2:2*numTarget+1
                    fprintf(f,'%.5f        \t',matrixTransferEntropy(j,z));
                end
            end
        end
        
        fclose(f);
        
        if (isfield(nameFields,'pValue'))
            fPVal = fopen([outDir '/report_pval_' methodNames{i,1} '.txt'],'w');
            combinationsTarDriv     = repmat('%12s \t ',1,2*numTarget + 3);
            combinationsTarDriv     = [combinationsTarDriv '%12s\n'];
            fprintf(fPVal,combinationsTarDriv,'Patient','modOrderB','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r','modOrderT','sp > t','rp > t','(r&s)p > t','rp > s','t > s','rp&t > s','s > r','t > r','s&t > r');
            fprintf(fPVal,'\n--------------------------------------------------------\n\n');
            
            for j = 1 : numSubj
                fprintf(fPVal,'\n       %2d           \t', matrixPValues(j,1));
                fprintf(fPVal,'%2d           \t', modelOrder(j,1));
                for z = 2:numTarget+1
                    fprintf(fPVal,'%.5f        \t',matrixPValues(j,z));
                end
                fprintf(fPVal,'%2d           \t', modelOrder(j,2));
                for z = numTarget+2:2*numTarget+1
                    fprintf(fPVal,'%.5f        \t',matrixPValues(j,z));
                end
            end
            fclose(fPVal);
        end
        
        transferEntropyMtx{1,i}            = matrixTransferEntropy;
        
    end
    
    save('entropyMtx','transferEntropyMtx');
    

return;