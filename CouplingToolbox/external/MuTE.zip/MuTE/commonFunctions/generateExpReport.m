function [] = generateExpReport(copyDir,resultDir,params)

%     copyDropboxDir              = [dropboxDir 'entropyMatrices_' num2str(n) '_series_' num2str(numSeries)  '/'];
%     if (~exist(copyDropboxDir,'dir'))
%         mkdir(copyDropboxDir);
%     end
%     currDir              = [pwd '/'];
    methodNames          = fieldnames(params.methods);
    numMethods           = length(methodNames);
%     transferEntropyMtx   = cell(1,numMethods);
%     significanceOnDriv   = cell(1,numMethods);
    

        for i = 1 : numMethods
            cd(resultDir)
            numTargets                         = length(params.methods.(methodNames{i,1}).idTargets);
            idDrivers                          = params.methods.(methodNames{i,1}).idDrivers;
            nameFiles                          = [methodNames{i,1} '*.mat'];
            subjFiles                          = dir(nameFiles);
            numSubj                            = length(subjFiles);
            significanceOnDrivers              = zeros(numSubj,numTargets);
            matrixTransferEntropy              = zeros(numSubj,(numTargets)+1);
    %         check if is present the pValues matrix
            checkPValuesField                  = load(subjFiles(1).name);
            fields                             = fieldnames(checkPValuesField);
            nameFields                         = checkPValuesField.(fields{1,1});
            if (isfield(nameFields,'pValue'))
                matrixPValues                  = zeros(numSubj,(numTargets)+1);
            end

            if (isfield(nameFields,'modelOrder'))
                modelOrder                     = zeros(numSubj,2);
            end

            if (isfield(nameFields,'testThreshold'))
                testThresholdMtx                     = zeros(numSubj,(numTargets)+1);
            end

            count = 0;
            for j = 1 : numSubj
                load(subjFiles(j).name);
                matrixTransferEntropy(j,2 : numTargets+1)                 = outputToStore.transferEntropy;
                matrixTransferEntropy(:,1)                                = (1:numSubj)';
                if (strcmp(methodNames{i,1},'nonUniTENearNeighbour') || strcmp(methodNames{i,1},'linearNonUniformTransferEntropy')...
                        || strcmp(methodNames{i,1},'nonUniformTransferEntropy') || strcmp(methodNames{i,1},'nonUniformTE_selectionVar')...
                        || strcmp(methodNames{i,1},'nonUniNeuralNet'))
                    for k = 1 : numTargets
                        for l = 1 : length(idDrivers(:,k))
                            if (~isempty(find(outputToStore.finalCandidatesMtx{1,k}{1,1}(:,1) == idDrivers(l,k),1)))
                                count = count + 1;
                            end
                        end
                        if count > 0
                           significanceOnDrivers(j,k) = 1;
                        end
                        count = 0;
                    end
                end
                if (isfield(nameFields,'pValue'))
                    matrixPValues(j,2 : numTargets+1)                     = outputToStore.pValue;
                    matrixPValues(:,1)                                   = (1:numSubj)';
                end

                if (isfield(nameFields,'testThreshold'))
                    testThresholdMtx(j,2 : numTargets+1)                  = outputToStore.testThreshold;
                    testThresholdMtx(:,1)                                = (1:numSubj)';
                end

                if (isfield(nameFields,'bestOrder'))
                    modelOrder(j,1)                                      = outputToStore.bestOrder;
                end
            end

            if (isfield(nameFields,'pValue'))
                cd(copyDir)
                save([methodNames{i} '_matrixPValues'],'matrixPValues');
%                 cd(copyDropboxDir)
%                 save(['matrixPValues_' title],'matrixPValues');
            end

            if (isfield(nameFields,'testThreshold'))
                cd(copyDir)
                save([methodNames{i} '_testThresholdMtx'],'testThresholdMtx');
%                 cd(copyDropboxDir)
%                 save(['testThresholdMtx_' title],'testThresholdMtx');
            end

%             transferEntropyMtx{1,i}            = matrixTransferEntropy;
            cd(copyDir)
            save([methodNames{i,1} '_transferEntropyMtx'],'matrixTransferEntropy');
%             significanceOnDriv{1,i}            = significanceOnDrivers;
            if (strcmp(methodNames{i,1},'nonUniTENearNeighbour') || strcmp(methodNames{i,1},'linearNonUniformTransferEntropy')...
                        || strcmp(methodNames{i,1},'nonUniformTransferEntropy') || strcmp(methodNames{i,1},'nonUniformTE_selectionVar')...
                         || strcmp(methodNames{i,1},'nonUniNeuralNet'))
                save([methodNames{i,1} '_significanceOnDriv'],'significanceOnDrivers');
            end
            cd(resultDir)
        end
    
    cd(copyDir)
%     save('transferEntropyMtx','transferEntropyMtx');
%     save('significanceOnDriv','significanceOnDriv');
%     cd(copyDropboxDir)
%     save(['transferEntropyMtx_' title],'transferEntropyMtx');
%     save(['significanceOnDriv_' title],'significanceOnDriv');

return;