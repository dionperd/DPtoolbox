function r = name(a)

r = a.name;
