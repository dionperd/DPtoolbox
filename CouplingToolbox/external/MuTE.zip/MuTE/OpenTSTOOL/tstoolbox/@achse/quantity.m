function r = quantity(a)

r = a.quantity;
