function l = label(a)

l = label(a.unit);
