function r = resolution(a)

r = a.resolution;
