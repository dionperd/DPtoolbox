function c = history(d)

%tstoolbox/@description/history
%   description/history
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt


c = char(d.history);

