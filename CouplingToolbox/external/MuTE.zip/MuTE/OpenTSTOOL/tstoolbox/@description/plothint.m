function p = plothint(d)
%tstoolbox/@description/plothint
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

error(nargchk(1,1,nargin));

p = d.plothint;
