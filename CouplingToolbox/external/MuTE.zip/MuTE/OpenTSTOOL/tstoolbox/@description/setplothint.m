function d = setplothint(d, p)
%tstoolbox/@description/setplothint
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

error(nargchk(2,2,nargin));

d.plothint = p;
