function display(u)

disp(' ');
disp([inputname(1), ' = '])
disp(' ');
disp(['Label     :   ' u.label]);
disp(['Name      :   ' u.name]);
disp(['Quantity  :   ' u.quantity.eng '  ' u.quantity.ger]);
