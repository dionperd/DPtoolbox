function adj = adjoint_system2(modes);
%function to determine the modes adjoint to a given set of modes.
%the input to the function is the set on modes in a matrix of the form 
% [m (dimension of each mode) x n (number of modes)]; 
%the output generates n adjoint modes. same form as the input
%the adjoint vectors are given by adj1 = a11*phi1 + a12*phi2 + ...
%in addition to the condition that adj_i*phi_j = delta(i,j)



m = size(modes,1); %dimension of each mode
n = size(modes,2); %number of modes

p1 = repmat(modes,n,1);
p1 = reshape(p1,m,n*n); % [phi1 phi1 ... phi2 phi2 ... ]
p2 = repmat(modes,1,n); % [phi1 phi2 .. phi1 phi2 ...]

p = dot(p1,p2);
p = reshape(p,n,n);

a = inv(p); %coefficient matrix.
a = a';

for ii = 1:n
    a_tmp = repmat(a(ii,:),m,1);
    adj(:,ii) = sum(a_tmp.*modes,2);
end