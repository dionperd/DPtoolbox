%Control and Task shuould be chan X time X trials matrix
nit = 8; alpha = 1.96; 
ntrials = 10; %no. of trials
NTrBoot = 5; % for bootstrapping NTrBoot<ntrials
windowlen = 100; % time points for ctr subspace <= time in Control Matrix
for it = 1:nit
    randit = randperm(ntrials);
    itrials = randit(1:NTrBoot);
    ROICtr = mean(Control(:,:,itrials),3);
    ROITask = mean(Task(:,:,itrials),3);
    
    [pc,temp_coeff,eigval,tsquare] =  princomp(ROICtr(:,1:windowlen)');
    eigpercent = (eigval/sum(eigval))*100;
    %figure; plot(eigpercent(1:5))
    
    % MLCS Analysis
    % Creating control subspace
    ControlBasis=[];
    n = 2;
    for ii=1:n
        ControlBasis = [ControlBasis pc(:,ii)];
    end   
    % reconstructing Task data
    recon_tempcoeff = ROITask' * ControlBasis;
    ReconROITask = zeros(size(ROITask));
    Dsq = ROITask.^2;
    Dsq2 = sum(Dsq,1);
    GoFTask=[];
    
    for ii=1:n
        ReconROITask = ReconROITask + ControlBasis(:,ii)*recon_tempcoeff(:,ii)';
        goodness = (ROITask'-ReconROITask').^2;
        %GoF = [GoF,(1-sum(goodness(:))/Dsq2)*100];
        GoFTask = [GoFTask,(1.-sum(goodness,2)./Dsq2')*100];
    end
  %  *************************************************************
  % Reconstructing original control data from the conrol subspace.
    clear recon*
    recon_tempcoeff = ROICtr' * ControlBasis;
    ReconROICtr = zeros(size(ROICtr));
    Dsq = ROICtr.^2;
    Dsq2 = sum(Dsq,1);
    GoFCtr=[];
    
    for ii=1:n
        ReconROICtr = ReconROICtr + ControlBasis(:,ii)*recon_tempcoeff(:,ii)';
        goodness = (ROICtr'-ReconROICtr').^2;
        %GoF = [GoF,(1-sum(goodness(:))/Dsq2)*100];
        GoFCtr = [GoFCtr,(1.-sum(goodness,2)./Dsq2')*100];
    end
    GoFCtrAll(it,:) = GoFCtr(:,n);
    GoFTaskAll(it,:) = GoFTask(:,n);
end

figure;
plot(mean(GoFCtrAll,1),'b','linewidth',2);hold on;plot(mean(GoFTaskAll,1),...
         'r','linewidth',2);legend('Ctr','Task');
upperCtr = mean(GoFCtrAll,1) + alpha*std(GoFCtrAll,0,1)./sqrt(nit);
lowerCtr = mean(GoFCtrAll,1) - alpha*std(GoFCtrAll,0,1)./sqrt(nit);
upperTask = mean(GoFTaskAll,1) + alpha*std(GoFTaskAll,0,1)./sqrt(nit);
lowerTask = mean(GoFTaskAll,1) - alpha*std(GoFTaskAll,0,1)./sqrt(nit);
hold on;
p1 = jbfill([1:size(GoFCtrAll,2)],upperCtr,lowerCtr,[0 0 1]);
set(p1,'edgecolor',[0 0 1])
hold on;
p2 = jbfill([1:size(GoFTaskAll,2)],upperTask,lowerTask,[1 0 0]);
set(p2,'edgecolor',[1 0 0])
