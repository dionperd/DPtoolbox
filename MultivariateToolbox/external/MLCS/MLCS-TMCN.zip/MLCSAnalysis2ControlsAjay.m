%Control1 & Control2 and Task shuould be chan X time X trials matrix
% This version of the code is for bootsrpaping
%parameters*****************************
nit = 8;
ntrials = 10; %no. of trials
NTrBoot = 5; % for bootstrapping NTrBoot<ntrials
windowlen = 100; % time points for ctr subspace <= time in Control Matrix
npc = 2; %no. of PC's required for creating control basis
%***************************************************************
% Creating Control subspace
[pc1,temp_coeff1,eigval1,tsquare1] =  princomp(Control1(:,1:windowlen)');
eigpercent1 = (eigval1/sum(eigval1))*100;

[pc2,temp_coeff2,eigval2,tsquare2] =  princomp(Control2(:,1:windowlen)');
eigpercent2 = (eigval2/sum(eigval2))*100;

% MLCS Analysis *******************************************************
% Creating control subspace
Basis1=[];
Basis2=[];
for ii=1:npc
    Basis1=[Basis1 pc1(:,ii)];
    Basis2=[Basis2 pc2(:,ii)];
end
origBasis=[Basis1 Basis2];
ControlBasis = adjoint_system2([Basis1 Basis2]);
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
for it = 1:nit
    randit = randperm(ntrials);
    itrials = randit(1:NTrBoot);
    ROITask = mean(Task(:,:,itrials),3);
    % reconstructing Task data
    recon_tempcoeff = ROITask' * ControlBasis;
    ReconROITask = zeros(size(ROITask));
    Dsq = ROITask.^2;
    Dsq2 = sum(Dsq,1);
    GoFTask=[];
    
    for ii=1:size(ControlBasis,2)
        ReconROITask = ReconROITask + ControlBasis(:,ii)*recon_tempcoeff(:,ii)';
        goodness = (ROITask'-ReconROITask').^2;
        %GoF = [GoF,(1-sum(goodness(:))/Dsq2)*100];
        GoFTask = [GoFTask,(1.-sum(goodness,2)./Dsq2')*100];
    end
    GoFTaskAll(it,:) = GoFTask(:,npc);
end
%Go